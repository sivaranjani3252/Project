myString = "This is a string."
print(myString)
print(myString + " is of the data type " + str(type(myString)))
firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)
myString = "This is a string."
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))

<class 'str'>
This is a string. is of the data type <class 'str'>
name = input("What is your name? ")print(name)
print(name)This is a string.                                            
<class 'str'>                                                
This is a string. is of the data type <class 'str'>              
waterfall                                                    
What is your name? Maria                                     
Maria  
color = input("What is your favorite color?  ")
animal = input("What is your favorite animal?  ")
print("{}, you like a {} {}!".format(name,color,animal))